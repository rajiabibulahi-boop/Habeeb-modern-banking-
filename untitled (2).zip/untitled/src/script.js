const balance = document.getElementById("balance");
const income = document.getElementById("income");
const expense = document.getElementById("expense");

const recipient = document.getElementById("recipient");
const amount = document.getElementById("amount");
const sendBtn = document.getElementById("sendBtn");

const history = document.getElementById("history");

let currentBalance = 250000;
let totalIncome = 0;
let totalExpense = 0;

let transactions = JSON.parse(localStorage.getItem("bankTransactions")) || [];

function saveData() {
    localStorage.setItem("bankTransactions", JSON.stringify(transactions));
}

function updateUI() {

    history.innerHTML = "";

    totalExpense = 0;

    transactions.forEach((item) => {

        totalExpense += item.amount;

        const li = document.createElement("li");

        li.innerHTML = `
            <span>${item.name}</span>
            <strong>-₦${item.amount.toLocaleString()}</strong>
        `;

        history.prepend(li);

    });

    currentBalance = 250000 - totalExpense;

    balance.textContent = "₦" + currentBalance.toLocaleString() + ".00";
    income.textContent = "₦" + totalIncome.toLocaleString() + ".00";
    expense.textContent = "₦" + totalExpense.toLocaleString() + ".00";

    saveData();
}

sendBtn.addEventListener("click", () => {

    const name = recipient.value.trim();
    const value = Number(amount.value);

    if (name === "" || value <= 0) {
        alert("Please enter a valid recipient and amount.");
        return;
    }

    if (value > currentBalance) {
        alert("Insufficient balance.");
        return;
    }

    transactions.push({
        name: name,
        amount: value
    });

    recipient.value = "";
    amount.value = "";

    updateUI();

    alert("✅ Transfer Successful!");

});

updateUI();